/// <reference types="cypress" />
describe("akakce test case", ()=>{

    it("Test Otomasyonu – UI",()=>{
        cy.visit("https://www.akakce.com/")
        cy.get('#H_rl_v8 > [href="https://www.akakce.com/akakcem/giris/"]').click()
        cy.get('#life').type('seda.ayydin3@gmail.com')
        cy.get('#lifp').type('Test123*')
        cy.get('#lfb').click()
        cy.get('#q').type("iphone")
        cy.get('button > i').click()
        cy.get('#CPL>li').eq(1).contains('Ürüne Git').click( {force: true} )
        cy.get('#pf_w_v8 > .ufo_v8').click({force: true})


    })
})