/// <reference types="cypress" />



describe('akakce Task', () => {

 let token
 let id

  it('get token', () => {

    cy.request({
      method: "POST",
      url: "https://restful-booker.herokuapp.com/auth",
      body: {
        username: "admin",
        password: "password123",
      },
      headers: {
        'content-type': 'application/json'
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      token = response.body.token
      cy.log(token)
    })
  })

  it('get booking ids', ()=>{

    cy.request({
      method: "GET",
      url: "https://restful-booker.herokuapp.com/booking",
      headers: {
        'content-type': 'application/json'
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      cy.log(JSON.stringify(response.body))
    })
  })

  it('create booking', ()=>{

    cy.request({
      method: "POST",
      url: "https://restful-booker.herokuapp.com/booking",
      body: {
        "firstname" : "Jim",
        "lastname" : "Brown",
        "totalprice" : 111,
        "depositpaid" : true,
        "bookingdates" : {
            "checkin" : "2018-01-01",
            "checkout" : "2019-01-01"
        },
        "additionalneeds" : "Breakfast"
      },
      headers: {
        'content-type': 'application/json',
        "accept" : 'application/json'
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      id = response.body.bookingid
      cy.log(JSON.stringify(response.body))
      cy.log(id)
    })
  })

  it('get booking with id', ()=>{

    cy.request({
      method: "GET",
      url: "https://restful-booker.herokuapp.com/booking/" + id,
      headers: {
        'content-type': 'application/json'
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      cy.log(JSON.stringify(response.body))
    })
  })

  it('update booking', ()=>{

    cy.request({
      method: "PUT",
      url: "https://restful-booker.herokuapp.com/booking/" + id,
      body: {
        "firstname" : "Jhon",
        "lastname" : "Doe",
        "totalprice" : 111,
        "depositpaid" : true,
        "bookingdates" : {
            "checkin" : "2018-01-01",
            "checkout" : "2019-01-01"
        },
        "additionalneeds" : "Breakfast"
      },
      headers: {
        'content-type': 'application/json',
        "accept" : 'application/json',
        'Cookie': 'token='+token
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      cy.log(JSON.stringify(response.body))
    })
  })

  it('partial update booking', ()=>{

    cy.request({
      method: "PATCH",
      url: "https://restful-booker.herokuapp.com/booking/" + id,
      body: {
        "firstname" : "Black",
        "lastname" : "Adam",
      },
      headers: {
        'content-type': 'application/json',
        "accept" : 'application/json',
        'Cookie': 'token='+token
      }
    }).then((response) => {
      expect(response).property('status').to.equal(200)
      cy.log(JSON.stringify(response.body))
    })
  })

  it('delete booking', ()=>{

    cy.request({
      method: "DELETE",
      url: "https://restful-booker.herokuapp.com/booking/" + id,
      headers: {
        'content-type': 'application/json',
        "accept" : 'application/json',
        'Cookie': 'token='+token
      }
    }).then((response) => {
      expect(response).property('status').to.equal(201)
      cy.log(JSON.stringify(response.body))
    })
  })

  })
 
